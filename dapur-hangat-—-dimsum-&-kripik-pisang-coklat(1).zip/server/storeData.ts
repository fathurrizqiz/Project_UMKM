import fs from 'fs';
import path from 'path';
import type {
  AdminNotification,
  Order,
  OrderStatus,
  Product,
  Review,
  StoreSettings,
} from '../src/types/store';

export interface StoreDatabase {
  products: Product[];
  settings: StoreSettings;
  orders: Order[];
  notifications: AdminNotification[];
  reviews: Review[];
}

const DATA_DIR = path.resolve(process.cwd(), 'data');
const DATA_FILE = path.join(DATA_DIR, 'store.json');

// Crisp default vector QRIS card encoded as data URI so QRIS preview is crisp immediately
// while allowing Admin to upload their own custom QRIS photo anytime.
const DEFAULT_QRIS_SVG = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 360" fill="none">
  <rect width="320" height="360" rx="16" fill="#FFFFFF"/>
  <rect x="8" y="8" width="304" height="344" rx="12" stroke="#E5E0D8" stroke-width="2"/>
  <rect x="24" y="22" width="84" height="24" rx="4" fill="#B91C1C"/>
  <text x="66" y="38" text-anchor="middle" fill="#FFFFFF" font-family="sans-serif" font-size="13" font-weight="700" letter-spacing="1.5">QRIS</text>
  <text x="296" y="38" text-anchor="end" fill="#57534E" font-family="sans-serif" font-size="11" font-weight="600">GPN · NASIONAL</text>
  <text x="160" y="68" text-anchor="middle" fill="#1C1917" font-family="sans-serif" font-size="14" font-weight="700">DAPUR HANGAT ID</text>
  <text x="160" y="84" text-anchor="middle" fill="#78716C" font-family="sans-serif" font-size="10">NMID: ID1026884920112</text>
  <g transform="translate(50, 98)">
    <rect width="220" height="220" rx="8" fill="#FFFFFF" stroke="#1C1917" stroke-width="2"/>
    <rect x="16" y="16" width="52" height="52" stroke="#1C1917" stroke-width="8" fill="none"/>
    <rect x="30" y="30" width="24" height="24" fill="#1C1917"/>
    <rect x="152" y="16" width="52" height="52" stroke="#1C1917" stroke-width="8" fill="none"/>
    <rect x="166" y="30" width="24" height="24" fill="#1C1917"/>
    <rect x="16" y="152" width="52" height="52" stroke="#1C1917" stroke-width="8" fill="none"/>
    <rect x="30" y="166" width="24" height="24" fill="#1C1917"/>
    <rect x="84" y="20" width="12" height="12" fill="#1C1917"/>
    <rect x="108" y="20" width="12" height="12" fill="#1C1917"/>
    <rect x="128" y="20" width="12" height="12" fill="#1C1917"/>
    <rect x="84" y="44" width="24" height="12" fill="#1C1917"/>
    <rect x="120" y="44" width="16" height="12" fill="#1C1917"/>
    <rect x="20" y="84" width="12" height="24" fill="#1C1917"/>
    <rect x="44" y="84" width="24" height="12" fill="#1C1917"/>
    <rect x="84" y="84" width="52" height="52" rx="6" fill="#B45309"/>
    <text x="110" y="114" text-anchor="middle" fill="#FFFFFF" font-family="sans-serif" font-size="13" font-weight="700">DH</text>
    <rect x="152" y="84" width="16" height="16" fill="#1C1917"/>
    <rect x="180" y="84" width="24" height="12" fill="#1C1917"/>
    <rect x="152" y="112" width="24" height="12" fill="#1C1917"/>
    <rect x="188" y="108" width="16" height="28" fill="#1C1917"/>
    <rect x="20" y="120" width="24" height="16" fill="#1C1917"/>
    <rect x="56" y="112" width="12" height="24" fill="#1C1917"/>
    <rect x="84" y="152" width="20" height="12" fill="#1C1917"/>
    <rect x="116" y="152" width="16" height="24" fill="#1C1917"/>
    <rect x="148" y="152" width="24" height="16" fill="#1C1917"/>
    <rect x="184" y="152" width="20" height="20" fill="#1C1917"/>
    <rect x="84" y="176" width="12" height="28" fill="#1C1917"/>
    <rect x="108" y="188" width="28" height="16" fill="#1C1917"/>
    <rect x="148" y="180" width="16" height="24" fill="#1C1917"/>
    <rect x="176" y="184" width="28" height="20" fill="#1C1917"/>
  </g>
  <text x="160" y="340" text-anchor="middle" fill="#57534E" font-family="sans-serif" font-size="10">Scan melalui GoPay · OVO · DANA · ShopeePay · Mobile Banking</text>
</svg>`;

export const DEFAULT_QRIS_DATA_URI = `data:image/svg+xml;utf8,${encodeURIComponent(DEFAULT_QRIS_SVG)}`;

export function createInitialSeed(): StoreDatabase {
  return {
    products: [
      {
        id: 'dimsum-ayam-original',
        name: 'Dimsum Ayam Original',
        category: 'Dimsum',
        price: 28000,
        stock: 24,
        unitLabel: '8 pcs + Chili Oil',
        description:
          'Olahan daging paha ayam segar giling halus dengan taburan wortel parut, dikukus hangat dan disajikan bersama chili oil rumahan.',
        imageUrl: '/src/assets/images/dimsum_ayam_original_1795090633232.jpg',
        featured: true,
        active: true,
      },
      {
        id: 'dimsum-mentai-bakar',
        name: 'Dimsum Mentai Bakar',
        category: 'Dimsum',
        price: 34000,
        stock: 16,
        unitLabel: '6 pcs + Saus Mentai',
        description:
          'Dimsum ayam udang lembut disiram saus mentai creamy yang dibakar ringan, lengkap dengan taburan tobiko dan irisan nori.',
        imageUrl: '/src/assets/images/dimsum_mentai_bakar_1795090633909.jpg',
        featured: true,
        active: true,
      },
      {
        id: 'dimsum-udang-jamur',
        name: 'Dimsum Udang Jamur Kuping',
        category: 'Dimsum',
        price: 32000,
        stock: 14,
        unitLabel: '8 pcs + Kecap Asin Cabe',
        description:
          'Isian udang utuh manis berpadu jamur kuping kenyal dalam balutan kulit tipis transparan, gurih tanpa pengawet.',
        imageUrl: '/src/assets/images/dimsum_udang_jamur_1795090634847.jpg',
        featured: false,
        active: true,
      },
      {
        id: 'kripik-coklat-lumer',
        name: 'Kripik Pisang Coklat Lumer Classic',
        category: 'Kripik Pisang Coklat',
        price: 22000,
        stock: 30,
        unitLabel: 'Pouch 200g',
        description:
          'Irisan tipis pisang kepok pilihan yang digoreng renyah keemasan lalu dibalut coklat susu leleh tebal yang tidak bikin enek.',
        imageUrl: '/src/assets/images/kripik_coklat_lumer_1795090641883.jpg',
        featured: true,
        active: true,
      },
      {
        id: 'kripik-dark-almond',
        name: 'Kripik Pisang Dark Choco Almond',
        category: 'Kripik Pisang Coklat',
        price: 35000,
        stock: 12,
        unitLabel: 'Jar 300g',
        description:
          'Perpaduan kripik pisang renyah dengan dark chocolate 70% dan taburan kacang almond panggang yang wangi dan gurih.',
        imageUrl: '/src/assets/images/kripik_dark_almond_1795090634518.jpg',
        featured: true,
        active: true,
      },
      {
        id: 'kripik-matcha-choco',
        name: 'Kripik Pisang Matcha Choco Crunch',
        category: 'Kripik Pisang Coklat',
        price: 25000,
        stock: 18,
        unitLabel: 'Pouch 200g',
        description:
          'Kripik pisang karamel setengah celup dark chocolate dan krim Uji matcha lembut, pas untuk teman minum teh sore.',
        imageUrl: '/src/assets/images/kripik_matcha_choco_1795090633888.jpg',
        featured: false,
        active: true,
      },
    ],
    settings: {
      storeName: 'Dapur Hangat',
      adminWhatsapp: '6281234567890',
      qrisImageUrl: DEFAULT_QRIS_DATA_URI,
      qrisMerchantName: 'DAPUR HANGAT ID',
      bankAccounts: [
        {
          id: 'bank-bca',
          bankName: 'BCA',
          accountNumber: '7480192831',
          accountHolder: 'Dapur Hangat Nusantara',
        },
        {
          id: 'bank-bri',
          bankName: 'BRI',
          accountNumber: '032901004819502',
          accountHolder: 'Dapur Hangat Nusantara',
        },
      ],
      eWallets: [
        {
          id: 'ew-dana',
          provider: 'DANA',
          number: '081234567890',
          accountHolder: 'Dapur Hangat',
        },
        {
          id: 'ew-gopay',
          provider: 'GoPay',
          number: '081234567890',
          accountHolder: 'Dapur Hangat',
        },
        {
          id: 'ew-ovo',
          provider: 'OVO',
          number: '081234567890',
          accountHolder: 'Dapur Hangat',
        },
      ],
      codNote: 'Pengantaran langsung area kota, bayar tunai saat pesanan diterima.',
    },
    orders: [
      {
        id: 'ord-seed-1',
        orderCode: 'DH-261119-4012',
        createdAt: new Date(Date.now() - 1000 * 60 * 45).toISOString(),
        customerName: 'Nadia Putri',
        customerPhone: '081344556677',
        customerAddress: 'Jl. Kemang Timur No. 18, Jakarta Selatan',
        notes: 'Chili oil ekstra 1 bungkus ya kak',
        items: [
          {
            productId: 'dimsum-mentai-bakar',
            name: 'Dimsum Mentai Bakar',
            category: 'Dimsum',
            price: 34000,
            quantity: 1,
            unitLabel: '6 pcs + Saus Mentai',
          },
          {
            productId: 'kripik-coklat-lumer',
            name: 'Kripik Pisang Coklat Lumer Classic',
            category: 'Kripik Pisang Coklat',
            price: 22000,
            quantity: 2,
            unitLabel: 'Pouch 200g',
          },
        ],
        totalAmount: 78000,
        paymentMethod: 'QRIS',
        paymentAccountSummary: 'QRIS DAPUR HANGAT ID',
        status: 'Diproses',
        whatsappNotificationSent: true,
        whatsappMessage: 'Pesanan DH-261119-4012 telah dikirim ke WhatsApp Admin.',
      },
    ],
    notifications: [
      {
        id: 'notif-seed-1',
        orderId: 'ord-seed-1',
        orderCode: 'DH-261119-4012',
        customerName: 'Nadia Putri',
        customerPhone: '081344556677',
        paymentMethod: 'QRIS',
        totalAmount: 78000,
        hasPaymentProof: false,
        messagePreview: 'Pesanan baru DH-261119-4012 (Rp 78.000) via QRIS.',
        createdAt: new Date(Date.now() - 1000 * 60 * 45).toISOString(),
        read: true,
      },
    ],
    reviews: createSeedReviews(),
  };
}

export function createSeedReviews(): Review[] {
  return [
    {
      id: 'rev-seed-1',
      orderCode: 'DH-261118-8821',
      customerName: 'Nadia Putri',
      itemsSummary: 'Dimsum Mentai Bakar, Kripik Pisang Coklat Lumer Classic',
      rating: 5,
      comment:
        'Dimsumnya masih hangat waktu sampai dan saus mentainya gurih tidak bikin enek. Kripik pisangnya renyah, lapisan coklatnya tebal.',
      createdAt: new Date(Date.now() - 1000 * 60 * 60 * 20).toISOString(),
    },
    {
      id: 'rev-seed-2',
      orderCode: 'DH-261117-5410',
      customerName: 'Hendra Wijaya',
      itemsSummary: 'Dimsum Ayam Original, Dimsum Udang Jamur Kuping',
      rating: 5,
      comment:
        'Pesan lewat WhatsApp cepat sekali responnya, bayar QRIS langsung diproses. Chili oil rumahan Dapur Hangat bikin nagih.',
      createdAt: new Date(Date.now() - 1000 * 60 * 60 * 44).toISOString(),
    },
    {
      id: 'rev-seed-3',
      orderCode: 'DH-261116-3109',
      customerName: 'Ayu Lestari',
      itemsSummary: 'Kripik Pisang Dark Choco Almond, Kripik Pisang Matcha Choco Crunch',
      rating: 5,
      comment:
        'Varian dark choco almond pas manisnya, tidak kemanisan dan almondnya wangi. Kemasan jar rapi untuk stok camilan kerja.',
      createdAt: new Date(Date.now() - 1000 * 60 * 60 * 72).toISOString(),
    },
  ];
}

export function loadDatabase(): StoreDatabase {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }
  if (!fs.existsSync(DATA_FILE)) {
    const seed = createInitialSeed();
    saveDatabase(seed);
    return seed;
  }
  try {
    const raw = fs.readFileSync(DATA_FILE, 'utf-8');
    const parsed = JSON.parse(raw) as StoreDatabase;
    if (!parsed || !Array.isArray(parsed.products) || !parsed.settings) {
      throw new Error('Corrupt store data');
    }
    if (!Array.isArray(parsed.reviews)) {
      parsed.reviews = createSeedReviews();
      saveDatabase(parsed);
    }
    return parsed;
  } catch {
    const seed = createInitialSeed();
    saveDatabase(seed);
    return seed;
  }
}

export function saveDatabase(db: StoreDatabase): void {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }
  const tmpFile = `${DATA_FILE}.tmp`;
  fs.writeFileSync(tmpFile, JSON.stringify(db, null, 2), 'utf-8');
  fs.renameSync(tmpFile, DATA_FILE);
}

export function isValidOrderStatus(status: string): status is OrderStatus {
  return [
    'Menunggu Pembayaran',
    'Menunggu Verifikasi',
    'Diproses',
    'Dikirim',
    'Selesai',
    'Dibatalkan',
  ].includes(status);
}
